load.initialize('Initialize', async function() {
	
});

load.action('Action', async function() {
	
});

load.finalize('Finalize', async function() {
	
});
